import * as React from 'react';
import { Text, View, StyleSheet, Image, TextInput, text, number, Button} from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>

      <Text style={styles.paragraph}>
        TESTE DE IMC
      </Text>

      <TextInput
        style={styles.input}
        value={number}
        placeholder="Altura"
      />
      <TextInput
        style={styles.input}
        value={number}
        placeholder="Peso"
      />

      <Text style={styles.espaco}></Text>

      <Button title="Calcular" color='#DC143C'/>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  input: {
    borderColor: '#B22222',
    height: 40,
    borderWidth: 1,
    padding: 10,
    marginBottom: 12,
    color: '#FF69B4',
  },
  paragraph: {
    margin: 24,
    marginTop: 30,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#DC143C',
  },
  espaco: {
    marginBottom: 10,
  },
  logo: {
    height: 138,
    width: 138,
  },
});
